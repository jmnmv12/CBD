import redis

r = redis.Redis()

print (r.info())

