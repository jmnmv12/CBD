## Redis Mass Insertion


```
cat initials4redis.txt | redis-cli --pipe
```